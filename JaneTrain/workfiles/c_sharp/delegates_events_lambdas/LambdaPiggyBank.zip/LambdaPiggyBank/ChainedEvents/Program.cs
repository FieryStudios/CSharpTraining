﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


// PARAMETERS: 
//  - Keep track of a balance.  
//  - Announce when user hits goal (if above 500).
//  - user can put money in or take money out.  
//  - accept exit as parameter
//  - same as earlier Piggy Bank, except use Lambda expressions instead of delegated methods

namespace LambdaPiggyBank
{
    // define the delegate for the deposit/withdrawal
    public delegate void bankTransaction(decimal transactionAmount, decimal currentBalance, decimal goal);

    class Bank
    {
        private decimal savingsGoal = 0m;

        public decimal goal {
            set {
                this.savingsGoal = value;
            }
            get
            {
                return this.savingsGoal;
            }
        }

        private decimal balance = 0m;

        private bool inDebt = false;

        // declare the event handler
        public event bankTransaction valueChanged;

        public decimal updateBalance
        {
            set
            {
                this.balance += value;

                // when the value changes, fire the event
                this.valueChanged(value, this.balance, goal);
            }
            get
            {
                return this.balance;
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // create the test class
            Bank Wilbur = new Bank();

            // Connect event handlers using lambdas

            //obj.valueChanged += (x) => {
            //    Console.WriteLine("The value changed to {0}", x);
            //};

            Wilbur.valueChanged += (transactionAmount, currentBalance, goal) => {
                // judge the transaction as deposit or withdrawal
                if (transactionAmount >= 0)
                {
                    Console.WriteLine("Congratulations! You made a deposit.");
                }
                else if (transactionAmount < 0)
                {
                    Console.WriteLine($"Your withdrawal is only keeping you from your goal of ${goal}!");
                }
            };
            Wilbur.valueChanged += (transactionAmount, currentBalance, goal) => {
                // report on the balance, and nag if it gets to zero or below

                if (currentBalance < goal && currentBalance > 0)
                {
                    Console.WriteLine($"Current piggybank balance: ${currentBalance}");
                }
                else if (currentBalance == 0)
                {
                    Console.WriteLine($"Start over at ${currentBalance}");
                }
                else if (currentBalance < 0)
                {
                    Console.WriteLine($"You're going into debt! ${currentBalance}");
                }
            };
            Wilbur.valueChanged += (transactionAmount, currentBalance, goal) => {
                // give a shoutout once the user hits their goal
                if (currentBalance > goal)
                {
                    Console.WriteLine($"HOORAY! You've hit your goal of {goal}! Go break your bank and buy something shiny.");
                }
            };

            string inputStr;
            decimal transaction;

            Console.WriteLine("Enter a positive, non-zero amount for your savings goal: ");
            inputStr = Console.ReadLine();

            if (!inputStr.Equals("exit"))
            {
                Decimal.TryParse(inputStr, out transaction);       
                Wilbur.goal = transaction;
                Console.WriteLine("Start using your piggy bank! ");
            }
            
            do {
               
                Console.WriteLine("Enter a numeric transaction amount: ");
                inputStr = Console.ReadLine();
                if (!inputStr.Equals("exit")) {
                    if (Decimal.TryParse(inputStr, out transaction))
                    {
                        Wilbur.updateBalance = transaction;
                    }
                    else {
                        break;
                    };            
                }

            } while (!inputStr.Equals("exit"));
            Console.WriteLine("Goodbye!");
        }
    }
}
