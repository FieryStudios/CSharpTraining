﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


// PARAMETERS: 
//  - Keep track of a balance.  
//  - Announce when user hits goal (if above 500).
//  - user can put money in or take money out.  
// -- accept exit as parameter
// TODO: Make it more like example with different classes
//      -  add a watcher to break out whenever a user hits goal
//      - allow user to set goal
namespace PiggyBank
{
    // define the delegate for the deposit/withdrawal
    public delegate void bankTransaction(decimal transactionAmount, decimal currentBalance, decimal goal);

    class Bank
    {
        private decimal savingsGoal = 0m;

        public decimal goal {
            set {
                this.savingsGoal = value;
            }
            get
            {
                return this.savingsGoal;
            }
        }

        private decimal balance = 0m;

        private bool inDebt = false;

        // declare the event handler
        public event bankTransaction valueChanged;

        public decimal updateBalance
        {
            set
            {
                this.balance += value;

                // when the value changes, fire the event
                this.valueChanged(value, this.balance, goal);
            }
            get
            {
                return this.balance;
            }
        }
    }

    class JudgeTransaction {
        public void judge(decimal transactionAmount, decimal currentBalance, decimal goal)
        {
            if (transactionAmount >= 0)
            {
                Console.WriteLine("Congratulations! You made a deposit.");                
            }
            else if (transactionAmount < 0)
            {
                Console.WriteLine($"Your withdrawal is only keeping you from your goal of ${goal}!");
            }
        }
    }

    class ReportBalance
    {
        public void reporter(decimal transactionAmount, decimal currentBalance, decimal goal)
        {
            if (currentBalance < goal && currentBalance > 0)
            {
                Console.WriteLine($"Current piggybank balance: ${currentBalance}");                
            }
            else if (currentBalance == 0)
            {
                Console.WriteLine($"Start over at ${currentBalance}");
            }
            else if (currentBalance < 0)
            {
                Console.WriteLine($"You're going into debt! ${currentBalance}");
            }

            
        }
    }
    class GoalTender {
        public void checkGoal(decimal transactionAmount, decimal currentBalance, decimal goal) {
            if (currentBalance > goal)
            {
                Console.WriteLine($"HOORAY! You've hit your goal of {goal}! Go break your bank and buy something shiny.");
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            // create the test class
            Bank Wilbur = new Bank();
            JudgeTransaction Judger = new JudgeTransaction();
            ReportBalance Reporter = new ReportBalance();
            GoalTender Goalie = new GoalTender();

            // Connect event handlers
            Wilbur.valueChanged += Judger.judge;
            Wilbur.valueChanged += Reporter.reporter;
            Wilbur.valueChanged += Goalie.checkGoal;

            string inputStr;
            decimal transaction;

            Console.WriteLine("Enter a positive, non-zero amount for your savings goal: ");
            inputStr = Console.ReadLine();

            if (!inputStr.Equals("exit"))
            {
                Decimal.TryParse(inputStr, out transaction);       
                Wilbur.goal = transaction;
                Console.WriteLine("Start using your piggy bank! ");
            }
            
            do {
               
                Console.WriteLine("Enter a numeric transaction amount: ");
                inputStr = Console.ReadLine();
                if (!inputStr.Equals("exit")) {
                    if (Decimal.TryParse(inputStr, out transaction))
                    {
                        Wilbur.updateBalance = transaction;
                    }
                    else {
                        break;
                    };            
                }

            } while (!inputStr.Equals("exit"));
            Console.WriteLine("Goodbye!");
        }
    }
}
