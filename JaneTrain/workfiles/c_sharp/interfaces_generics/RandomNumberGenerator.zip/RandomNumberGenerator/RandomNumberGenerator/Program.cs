﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// This Console App must:
//    - accept an integer from the user
//    - generate a random floating point number between 0 and the user's number
//     - do nothing if the input value is not a number
//    - quit when the user types "exit"
//    - implement an IRandomizable interface
//        - with one method, GetRandomNUm
//            - that accepts the upper bound as a parameter
//            - and returns the random number
//    - the class implements this interface.


namespace RandomNumberGenerator
{
    interface IRandomizable {
        float GetRandomNum(double upperBound);
    }

    class FloatGetter : IRandomizable {
        public float GetRandomNum(double upperBound) {
            Random R = new Random();
            double D = R.NextDouble() * upperBound;       
            return (float)D;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            FloatGetter getAFloat = new FloatGetter();

            string inputStr;
            double upperBound;
            Console.Write("\nI will generate you a random number between 0 and a number of your choice. ");
            do
            {
                Console.Write("\nEnter a positive-value upper bound value (or 'exit' to quit): ");
                inputStr = Console.ReadLine();

                if (inputStr == "exit") { break; }

                if (Double.TryParse(inputStr, out upperBound))
                {
                    float haveAFloat = getAFloat.GetRandomNum(upperBound);

                    Console.WriteLine($"\n Your floating number between 0 and {upperBound}: {haveAFloat} ");
                    
                }
                    
                else {
                    Console.Write("Please enter a positive-value upper bound Double: ");
                    inputStr = Console.ReadLine();
                    continue;
                }
            } while (inputStr != "exit");

            Console.WriteLine("\n Press any key to continue.");

            Console.ReadKey();
        }
        
    }

}
