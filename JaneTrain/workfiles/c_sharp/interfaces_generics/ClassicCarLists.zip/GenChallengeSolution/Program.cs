﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassicCarLists
{
    public class ClassicCar
    {
        public string m_Make;
        public string m_Model;
        public int m_Year;
        public int m_Value;

        public ClassicCar(string make, string model, int year, int val) {
            m_Make = make;
            m_Model = model;
            m_Year = year;
            m_Value = val;
        }
    }
    
    class Program
    {
        static void Main(string[] args) {
            List<ClassicCar> carList = new List<ClassicCar>();
            populateData(carList);

            // How many cars are in the collection?

            Console.WriteLine($"There are {carList.Count()} cars total,");
            // How many Fords are there?

            var fordCount = 0;
            double mostExpensiveValue = 0;
            ClassicCar mostExpensiveCar = null;
            double totalValue = 0;
            Dictionary<string, bool> carManufacturers = new Dictionary<string, bool>();


            foreach (ClassicCar car in carList) {
                if (car.m_Make == "Ford") {
                    fordCount++;
                };

                if (car.m_Value >= mostExpensiveValue)
                {
                    mostExpensiveValue = car.m_Value;
                    mostExpensiveCar = car;
                };

                totalValue += car.m_Value;

                // use a dictionary rather than a list, because it'll throw an error if there's already an existing key for that make
                try
                {
                    carManufacturers.Add(car.m_Make, true);
                }
                catch (Exception e) {
                    // do nothing
                }
            }

            Console.WriteLine($"\n and there are {fordCount} Ford cars.");

            // could also use the FindAll function:

            List<ClassicCar> fordList = carList.FindAll(FindFords);
            Console.WriteLine($"\n Alternate count: there are {fordList.Count} Ford cars.");

            // What is the most valuable car?

            Console.WriteLine($"\nThe total collection is worth {totalValue}.");

            Console.WriteLine($"\nThe most expensive car in the list is a {mostExpensiveCar.m_Year} {mostExpensiveCar.m_Make} {mostExpensiveCar.m_Model} that costs ${mostExpensiveValue},");

            // How many unique manufacturers are there?
            Console.WriteLine($"\n and there are {carManufacturers.Count} different car manufacturers.");

            Console.WriteLine("\nHit Enter key to continue...");
            Console.ReadLine();
        }

        // delegate, used by .FindAll to find number of Ford cars
        static bool FindFords(ClassicCar car)
        {
            if (car.m_Make == "Ford")
            {
                return true;
            }
            else {
                return false;
            }
        }
        static void populateData(List<ClassicCar> theList) {
            theList.Add(new ClassicCar("Alfa Romeo", "Spider Veloce", 1965, 15000));
            theList.Add(new ClassicCar("Alfa Romeo", "1750 Berlina", 1970, 20000));
            theList.Add(new ClassicCar("Alfa Romeo", "Giuletta", 1978, 45000));

            theList.Add(new ClassicCar("Ford", "Thunderbird", 1971, 35000));
            theList.Add(new ClassicCar("Ford", "Mustang", 1976, 29800));
            theList.Add(new ClassicCar("Ford", "Corsair", 1970, 17900));
            theList.Add(new ClassicCar("Ford", "LTD", 1969, 12000));

            theList.Add(new ClassicCar("Chevrolet", "Camaro", 1979, 7000));
            theList.Add(new ClassicCar("Chevrolet", "Corvette Stringray", 1966, 21000));
            theList.Add(new ClassicCar("Chevrolet", "Monte Carlo", 1984, 10000));

            theList.Add(new ClassicCar("Mercedes", "300SL Roadster", 1957, 19800));
            theList.Add(new ClassicCar("Mercedes", "SSKL", 1930, 14300));
            theList.Add(new ClassicCar("Mercedes", "130H", 1936, 18400));
            theList.Add(new ClassicCar("Mercedes", "250SL", 1968, 13200));
        }
    }
}
