﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


// What happens when you have multiple interfaces, each of which defines a method of the same name?


namespace ExplicitInterfaces
{
    interface IFirePhotonTorpeods
    {
        void makeItSo(string crewMember, int torpCount, double range);
    }
    interface IGoToWarp
    {
        void makeItSo(string crewMember, int warpFactor, string order);
    }
    interface IPlotNewCourse
    {
        void makeItSo(string crewMember, string destination);
    }

    class Enterprise : IFirePhotonTorpeods, IGoToWarp, IPlotNewCourse
    {

        // using explicit naming allows you to call the same method on different interfaces without collision

        public void makeItSo(string crewMember)
        {
            Console.WriteLine($"\nMake it so, {crewMember}.");
        }

        void IFirePhotonTorpeods.makeItSo(string crewMember, int torpCount, double range)
        {
            Console.WriteLine($"\n{crewMember}! Fire {torpCount} Photon Torpedoes, at range {range}.");
        }

        void IGoToWarp.makeItSo(string crewMember, int warpFactor, string order)
        {
            Console.WriteLine($"\n{crewMember}, take us to Warp Factor {warpFactor}.");
            Console.WriteLine($"\n   {order}\n");
        }

        void IPlotNewCourse.makeItSo(string crewMember, string destination)
        {
            Console.WriteLine($"\nShut up, {crewMember}. \n  Lieutenant Yar, set a course for {destination}.");
        }

       
    }

    class Program
    {
        static void Main(string[] args) {
            Enterprise NCC1701D = new Enterprise();
            NCC1701D.makeItSo("Number One");

            IFirePhotonTorpeods phoTorps = NCC1701D as IFirePhotonTorpeods;
            phoTorps.makeItSo("Lieutenant Worf", 2, 4.50);

            IGoToWarp warpDrive = NCC1701D as IGoToWarp;
            warpDrive.makeItSo("Commander Data", 3, "Engage.");

            IPlotNewCourse newWorlds = NCC1701D as IPlotNewCourse;
            newWorlds.makeItSo("Wesley", "The Romulan Homeworld");

            Console.WriteLine("\nPress Enter key to continue...");
            Console.ReadLine();
        }
    }
}
